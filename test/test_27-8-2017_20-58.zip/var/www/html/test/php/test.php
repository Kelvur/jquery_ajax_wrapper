<?php

$data = array('definition'=>array('#', 'Name', 'Surname'), 'values'=>array( array('000001', 'Lorem', 'Ipsum'), array('000002', 'Dolor', 'Sit'), array('000003', 'Amet', 'Consectetur')));

echo json_encode($data);

?>
