const TEST_URL = 'php/test.php';

$('#test-button').click(function(){
	wrapper_ajax(TEST_URL, {}, print_table);
});

function print_table(data, status, jqXHR){
	var id_element = '#test-table';
	print_table_header(id_element, data.definition);
	print_table_body(id_element, data.values);
}

function print_table_header(id_element, data){
	var tr = document.createElement('tr');
	$(id_element).append('<thead></thead>');
	$(id_element).find('thead').append(tr);
	data.forEach(function(value, index, array){
		let td = document.createElement('td');
		td.innerHTML = value;
		tr.appendChild(td);
	});
}

function print_table_body(id_element, data){
	var tbody = document.createElement('tbody');
	$(id_element).append(tbody);
	data.forEach(function(values, index, array){
		var tr = document.createElement('tr');
		tbody.appendChild(tr);
		values.forEach(function(value, index, array){
			var td = document.createElement('td');
			tr.appendChild(td);
			td.innerHTML = value;
		});
	});
}
